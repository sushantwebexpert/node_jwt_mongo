import { Component, Input, OnInit } from '@angular/core';
import * as WordCloud from 'wordcloud';
declare var $: any; 

@Component({
  selector: 'app-wordcloud',
  templateUrl: './wordcloud.component.html',
  styleUrls: ['./wordcloud.component.scss']
})
export class WordcloudComponent implements OnInit {
  @Input() options: any;

  
  ngOnInit() {

  }

  maskChange(){

  }

  run2() {

  }


}
