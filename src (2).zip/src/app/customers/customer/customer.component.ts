import { Component } from '@angular/core';
const APP_USER_PROFILE = "dearframes_user"

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss']
})
export class CustomerComponent {
constructor() {

      // let isLoggedIn = localStorage.getItem(APP_USER_PROFILE);
      //   if (isLoggedIn) {
      //   let u = JSON.parse(isLoggedIn);
      //   console.log(u)

      // }
    }
}
