import { Component, Input, OnInit, SimpleChanges } from "@angular/core";
import * as WordCloud from "wordcloud";
declare var $: any;
import { EventsService } from "../../services/events.service";

@Component({
  selector: "app-wordcloud",
  templateUrl: "./wordcloud.component.html",
  styleUrls: ["./wordcloud.component.scss"],
})
export class WordcloudComponent implements OnInit {
  @Input() wcp_options: any;

  maskCanvas2: any;
  orgUrl2: any;

  cwidth: any = 800;
  cheight: any = 600;

  option: any = {
    gridSize: 5,
    weightFactor: function (size: any) {
      return (Math.pow(size, 2.3) * 800) / 1024;
    },
    fontFamily: "Francois One, sans-serif",
    fontWeight: 'bold',
    color: function (word: any, weight: any) {
      return weight === 12 ? "#f44222" : "#c44292";
    },
    rotateRatio: 0.5,
    rotationSteps: 2,
    backgroundColor: "#ffe0e0",
    fileUrl:
      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOkAAAB3CAYAAADmW2fQAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAAZdEVYdFNvZnR3YXJlAEFkb2JlIEltYWdlUmVhZHlxyWU8AAADc2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS41LWMwMjEgNzkuMTU0OTExLCAyMDEzLzEwLzI5LTExOjQ3OjE2ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOmMyZDI0ZWZmLTdkNmItNDA2Mi1iY2ZhLTBlYTU1ZWZiNjE0OSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoxRjNDQTU2MDdDRjExMUUzQkREODk1MjNBMkVBMjhGNiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoxRjNDQTU1RjdDRjExMUUzQkREODk1MjNBMkVBMjhGNiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3OWU0OTAzNS1lZjEwLTQ4NjgtODMxYi1kYjgwNGI2ZWU1MzEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6YzJkMjRlZmYtN2Q2Yi00MDYyLWJjZmEtMGVhNTVlZmI2MTQ5Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+r1r3tgAACk9JREFUeF7tnT126joUhQ9vLDgFixGIEUAaKtp0pkyadLdMl8aUoaNNRYMZQRgBiwJ5Ln4SmHtJQgiWjm3J2t96uo/cn8Sy9taRZPmokysIAOAs/xX/BwA4CkwKgOPcNNzNsqz4VIYudbvFRwCAMb+bNJvRIHqiTfHlzYiE5MejsioAwAYMdwFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMeBSQFwHJgUAMcJM6VnllEmJcn9npa7XfGbRNvtVv3ap37/+DX1ejS+uyOKIoq6Xa/Tk2bZmuRqqep7quc5us6qruN7Gg4DSsLqiQ7CMKlqjPXqlV7e57QpXZFzBIl4QhMl5kcPxJytZ/T68kTzknUWIqY/i2caXsluns2m9PD+1ey/058s6O2xoXvnqw60Sa8ik1yov6b/aqkiklwW36IZZC7TOBfiwrUxFREnedpsJS9yqPeF6y1dRPxj/WQiLv+bX4pI6r5h/uuglSZlE+mNxRmzyjSPKxDjJWP5YNK26KBdJq1IpLcVkce1R4kzqhbkl/Z02qQt00FrTFp3r/ljaaJzUnW/eC3c5axurpq0jTpoxSOYbDagaDQvv7hVBZsnigZTWhdfVs56Sh1V91rQdZvWVrPStFUH3pv00DBPTjTLPzZzGnXqMOqapnUZ9MR8RIOZyVGY1dJmHXhtUicb5i+qgQYzqk7OGc0GI/VT6mfz9ECv/x4rNk7rdVAMe3/G1Tmp6XXVXeK0uGBm6pqHMhf2OWkAOvA0kqoo8mCwwaIJ1PCQfxqn6v/SRAx1jTB04KVJs9kDOTu6ucD8hXnYu371qv5VEYoOPDTpml59U+jmiR7YFlsQRY+EowPvTJrNXvgXS4RQ/30u3GzeVzzRNFvRO5s2BcVJQqneZK6Kmv4civ4sZUppEutb4yRB6eAwM72GUwtHaR5f+lkG5biF65crVH+uhMq2MMGxhmS6ieBzEXlSYv+aTBO2HTw8C0dh6cAvk3KsaKrrKr+/UjcSgzkYXJrGF75vmWLcLuoe2P5sVVhMGpgOvDKprUiErUmsl/tjFQNssIwg1m0i88QyonKYNDQdeDQnzWhf/vXFf8QpfbwNiy8M6T7Sh1KIOXNa2jyOyfZkfgsEJQvb93u79LhI1HdqkvB04I9JrRZMYkptG+bE8I1s2me7t1g+kjvjZ4IiWRDLu9ZKoAsVThsjQB34Y1IrgT4TU9McGL6lqrnN2Oxk8ak8mXEIETS558sg0L2fNBdNA9SBNyY1F2hMf9jTdQxpbNo6273xoxi5M5SnmBCjR7VLadKQS0PUgTcmNRZoPGbtPU8MTVtnsyOzWGo+FxOTe+ZcU126OyXpqpkQdeCJSS0E2ouKT8wMx4ZDnS3ZTEtN6N9xR5CmCFMH/sxJjeCdi30mop7RkG9DFtNSAwRVoc/IrPIN4bcOPDGpJNNRTnXUPeQzvQd9ak0gDVQHLY+kbRIoMMdvHbTcpAD4D0wKgOPApAA4DkwKgOPApAA4DkwKgOPApAA4DkwKgOPApAA4DkwKgOPApAA4DkwKgOO03KT1v7sJXMRvHXhiUtN39qrEMmtdbbSpowpTBy2PpFW+YG36bqPpS9guCtQX/NaBJyY1f7F2bpXo9grrpeFZJHW/21iNQI1zDVkRpg68iaTG6Trmy0qOxTfPWmeKSwJtbqgfog68MWnXOEeFZdb4i1gcuyd6auBqhjMCZT3ZrRwh6sCfOWnUU6N4M+ajKatIbY7d40+veQu8As1W72oQ3RAh6qA4E+ZnjA+nsT2c6CuWhwUxnGh2wPKwHqvLsPrZXO1hd2iU/YFN4emgQpPynMd5jvVpWrYCsWwYe6NYnqrG0CCNt4EiNB1UalL24w8ZzqXUx96ZXJNUP9uuYVSxNgnD0YOG9deksf3ZnBwmDU0H1Zr0UEQeJ2mepjKX8nMpD9cJz8druuUKOE+5tvaoguWkb6F68jK3X6bWncOpsJg0MB109C/qH15hTdPOyHiC/DOCEvlR+ji+bDagyHRF7SKChOhT/8ui4XY7pw3r6khMaf5mfx5JNqNB9MSycCNETJM/z3Qfdan7tR2yjDK5oteXd5oz3ghlUvpgODgpKB0crHoV+yHW5SJys06Vqxett/BEEE1V7VFP4bsP4ejghkcwdR+n8BtDelYq9QvOY/e6dN/UuYNOEZAOCrNeh2Gi/r2YRlKNX70ox1z0M35GEV34IqkmDB3cZtJKboaNSRWVdBwVFH6HHmBZQGqg8JpUEYAObjRpFaKwNKnCfaFyb+g4p9m5qRBm957dpIq26+Bmk/JHU3uTamwfbFdXeOp3FevHY4ZFJHlqaIwqTKppsw5KmJS7x+ISsXSwgWow6Inah3vHuplqoSqTtlkHpUyq4bsRvEJ2ZshTdqMAA3XW/TS1cs+kR9qog9Im5eux+KON3hXSyPCvKDZb7mxh2a72S4nPVOeqSTVt04GBSY/Y91hVDQl1J1Jzb9pA9LyImqNybV37XL63lcsmPdIeHRib9IDe02l8I6oyaYE8NlKlPapqlMQJd56j6p3wRVURX35Jwn2TFrRAB3Ym/YsWhu7Fy9yMik16hh7+mHcmX4qq42FTtmve/IY8DoENI6v4JSp4Y9IzfNXBDRvszcmy67kku992ddfAYeO4pNV+Sbud3kB9LUeN3nDdo974ju6iiIZNXC8Lqs7rFa2WO3ov6rs53zWunKw6V1XXiarrPd0Pu79mDTDd4K5MyrLB3hqPdFCpSUF7WU87NDJ4NSpOc3qzfhUoLPzJcQQcwpfE4O0AJgUG1J0YPGxgUlAebxKDtwOYFJRmvTTM02GRczhkYNI2kq3VrLEishm9mHq0kZzD/gOTto31lAbRiKIBbyLoIxnNHszzK/Ux1jUCJm0RmTJoZzQ/mmgzp5E2KltIzZT/IzLP/RXTGI9ejIBJW8Jhc8HXB5faqNGAptZOVRF0EBk9F/1LPLbPlBgoMGkLuL77Z0PzUUSdQ1Qta1a9U0kNnzs2EfRIjDBqjt5xBHzF5E0Pvec0yVMpL26c15tRZXp8cYJtUzr3SQaBgW2B3nIcgrLmh64IbAW0A8NdL/HHoCqK0jMMagVM6h1rmvpiUH2UyOIRz0YtgUl9I9vT1guD6iC6KH3WD/gO5qQ+UjwPdZo4pRwTURYQSX1k+EbS5XNQ1DxUwqBswKSe0n38cNOo2qAfmIdyApN6zMGoaXxIfeICOjVKDoOyA5N6TlcNfT9kSkncoFVFTInM3chd1EJg0jbQHdLjm46qCdXrVUFxkqrh7RtWcSsEq7stJFvP6PXlieZVPaoRypx/FvR8Q1ZBYA9M2moyWs9WtHx/V4a1c6xQQ9r+ZEzP90PyNrOpp8CkIVHkmpW0p+Vyd/y97ZZOif/6/X7xiag3HtMdRRRFKlrClI0CkwLgOFg4AsBxYFIAHAcmBcBxYFIAnIbof4lt1tM7RYA1AAAAAElFTkSuQmCC",
  };
  $list2: any = [
    ["Love", 12],
    ["Love", 5],
    ["Love", 5],
    ["Love", 5],
    ["Love", 5],
    ["Love", 5],
    ["Love", 5],
    ["Love", 5],
    ["Love", 5],
    ["Love", 5],
    ["Love", 5],
    ["Love", 8],
    ["Love", 5],
    ["Love", 5],
    ["Love", 2],
    ["Love", 2],
    ["Love", 4],
    ["Love", 4],
    ["Love", 4],
    ["Love", 5],
    ["Love", 6],
    ["Love", 8],
    ["Love", 8],
    ["Love", 8],
  ];

  constructor(public events: EventsService) {
    this.events.subscribe("option:updated", (data: any) => {
      this.wcp_options = data.option;
      this.orgUrl2 = data.orgUrl;
      this.makeRun();
      console.log(data);
    });
  }

  ngOnInit() {
    this.option["list"] = new Array(50).fill(this.$list2).flat();
  }

  makeRun() {
    if (this.wcp_options.fileUrl != null) {
      this.maskChange();
    }
  }

  run() {}

  maskChange() {
    var cw = this.cwidth;
    var ch = this.cheight;

    var options: any = {};

    options = this.wcp_options;

    var maskCanvas = null;

    var url = options.fileUrl;

    var img = new Image();
    img.src = url;

    // img.onload = function readPixels() {
    img.addEventListener("load", function () {
      window.URL.revokeObjectURL(url);

      maskCanvas = document.createElement("canvas");

      // this.maskCanvas = ;
      maskCanvas.width = img.width;
      maskCanvas.height = img.height;

      var ctx: any = maskCanvas.getContext("2d");

      ctx.drawImage(img, 0, 0, img.width, img.height);

      var imageData: any = ctx.getImageData(
        0,
        0,
        maskCanvas.width,
        maskCanvas.height
      );
      var newImageData: any = ctx.createImageData(imageData);

      for (var i = 0; i < imageData.data.length; i += 4) {
        var tone =
          imageData.data[i] + imageData.data[i + 1] + imageData.data[i + 2];
        var alpha = imageData.data[i + 3];

        if (alpha < 128 || tone > 128 * 3) {
          // Area not to draw
          newImageData.data[i] =
            newImageData.data[i + 1] =
            newImageData.data[i + 2] =
              255;
          newImageData.data[i + 3] = 0;
        } else {
          // Area to draw
          newImageData.data[i] =
            newImageData.data[i + 1] =
            newImageData.data[i + 2] =
              0;
          newImageData.data[i + 3] = 255;
        }
      }

      // maskCanvas =  maskCanvas;
      // maskCanvas;

      ctx.putImageData(newImageData, 0, 0);

      var $form = $("#form");
      var $canvas = $("#canvas");
      var $loading = $("#loading");

      var $mask = <HTMLInputElement>document.getElementById("config-mask");

      $loading.prop("hidden", false);

      var devicePixelRatio = 1;

      // Set the width and height
      var width = cw;
      var height = Math.floor(width * 0.65);
      var pixelWidth = width;
      var pixelHeight = height;

      $canvas.css({ width: "", height: "" });

      $canvas.attr("width", pixelWidth);
      $canvas.attr("height", pixelHeight);

      if (maskCanvas) {
        options.clearCanvas = false;

        /* Determine bgPixel by creating
             another canvas and fill the specified background color. */
        var bctx: any = document.createElement("canvas").getContext("2d");

        bctx.fillStyle = options.backgroundColor || "#fff";
        bctx.fillRect(0, 0, 1, 1);
        var bgPixel = bctx.getImageData(0, 0, 1, 1).data;

        var maskCanvasScaled: any = document.createElement("canvas");
        maskCanvasScaled.width = $canvas[0].width;
        maskCanvasScaled.height = $canvas[0].height;
        var ctx2: any = maskCanvasScaled.getContext("2d");

        ctx2.drawImage(
          maskCanvas,
          0,
          0,
          maskCanvas.width,
          maskCanvas.height,
          0,
          0,
          maskCanvasScaled.width,
          maskCanvasScaled.height
        );

        var imageData: any = ctx2.getImageData(0, 0, cw, ch);

        var newImageData: any = ctx2.createImageData(imageData);
        for (var i = 0; i < imageData.data.length; i += 4) {
          if (imageData.data[i + 3] > 128) {
            newImageData.data[i] = bgPixel[0];
            newImageData.data[i + 1] = bgPixel[1];
            newImageData.data[i + 2] = bgPixel[2];
            newImageData.data[i + 3] = bgPixel[3];
          } else {
            // This color must not be the same w/ the bgPixel.
            newImageData.data[i] = bgPixel[0];
            newImageData.data[i + 1] = bgPixel[1];
            newImageData.data[i + 2] = bgPixel[2];
            newImageData.data[i + 3] = bgPixel[3] ? bgPixel[3] - 1 : 0;
          }
        }

        ctx2.putImageData(newImageData, 0, 0);

        ctx2 = $canvas[0].getContext("2d");
        ctx2.drawImage(maskCanvasScaled, 0, 0);

        maskCanvasScaled =
          ctx2 =
          imageData =
          newImageData =
          bctx =
          bgPixel =
            undefined;
      }

      console.log(options);

      setTimeout(() => {
        WordCloud($canvas[0], options);
      });
    });

    console.log(this.orgUrl2);

    var $canvas = $("#canvas");

    var ctx2 = $canvas[0].getContext("2d");
    var img2 = new Image();
    img2.src = this.orgUrl2;

    img2.onload = function () {
      ctx2.globalAlpha = 0.04;
      ctx2.drawImage(img2, 0, 0, 940, 611);
      ctx2.globalAlpha = 1.0;
    };
  }
}
