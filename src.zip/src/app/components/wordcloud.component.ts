import { Component, Input, OnInit } from '@angular/core';
import * as WordCloud from 'wordcloud';
// import * as $ from 'jquery';
declare var $: any; 

@Component({
  selector: 'app-wordcloud',
  templateUrl: './wordcloud.component.html',
  styleUrls: ['./wordcloud.component.scss']
})
export class WordcloudComponent implements OnInit {
  @Input() options: any;

  maskCanvas2:any;

  option:any = {
    'gridSize': Math.round(16 * $('#canvas').width() / 1024),
    'weightFactor' : function (size:any) {return Math.pow(size, 2.3) * $('#canvas').width() / 1024;},
    'fontFamily': 'Times, serif',
    'color': function (word:any, weight:any) {return (weight === 12) ? '#f44222' : '#c44292';},
    'rotateRatio': 0.5,
    'rotationSteps': 2,
    'backgroundColor': '#ffe0e0'
  }
  $list2:any = [
        ['Love', 12],
        ['Love', 5],
        ['Love', 5],
        ['Love', 5],
        ['Love', 5],
        ['Love', 5],
        ['Love', 5],
        ['Love', 5],
        ['Love', 5],
        ['Love', 5],
        ['Love', 5],
        ['Love', 8],
        ['Love', 5],
        ['Love', 5],
        ['Love', 2],
        ['Love', 2],
        ['Love', 4],
        ['Love', 4],
        ['Love', 4],
        ['Love', 5],
        ['Love', 6],
        ['Love', 8],
        ['Love', 8],
        ['Love', 8],
      ];

    

  ngOnInit() {

    this.option['list'] = new Array(50).fill(this.$list2).flat();

    
      var $form = $('#form');
      var $canvas = $('#canvas');
      var $loading = $('#loading');

      var $width = $('#config-width');
      var $height = $('#config-height');
      var $mask = <HTMLInputElement>document.getElementById('config-mask');
      var $dppx = $('#config-dppx');
      var $css = $('#config-css');
      var $webfontLink = $('#link-webfont');



      if (!WordCloud.isSupported) {
        $('#not-supported').prop('hidden', false);
        $form.find('textarea, input, select, button').prop('disabled', true);
        return;
      }

      $canvas.on('wordcloudstop', function wordcloudstopped(evt:any) {
        $loading.prop('hidden', true);
      });

      // $mask.on('change', function() {
        
      // });

      // if ($mask[0].files.length) {
      //   $mask.trigger('change');
      // }

      // var $examples = $('#examples');
      // $examples.on('change', function loadExample(evt) {
      //   run();
      //   this.selectedIndex = 0;
      //   $examples.blur();
      // });


      // var hashChanged = function hashChanged() {
      //   run();
      // }

      // $(window).on('hashchange', hashChanged);
      // hashChanged();
      
    

  }

  run() {

      // var $form = $('#form');
      // var $canvas = $('#canvas');
      // var $loading = $('#loading');

      // var $width = $('#config-width');
      // var $height = $('#config-height');
      // var $mask = <HTMLInputElement>document.getElementById('config-mask');
      // var $dppx = $('#config-dppx');
      // var $css = $('#config-css');
      // var $webfontLink = $('#link-webfont');

      //   $loading.prop('hidden', false);

      //   // Load web font
      //   $webfontLink.prop('href', $css.val());

      //   // devicePixelRatio
      //   var devicePixelRatio = parseFloat($dppx.val());

      //   // Set the width and height
      //   var width = $width.val() ? $width.val() : $('#canvas-container').width();
      //   var height = $height.val() ? $height.val() : Math.floor(width * 0.65);
      //   var pixelWidth = width;
      //   var pixelHeight = height;

      //   if (devicePixelRatio !== 1) {
      //     $canvas.css({'width': width + 'px', 'height': height + 'px'});

      //     pixelWidth *= devicePixelRatio;
      //     pixelHeight *= devicePixelRatio;
      //   } else {
      //     $canvas.css({'width': '', 'height': '' });
      //   }

      //   $canvas.attr('width', pixelWidth);
      //   $canvas.attr('height', pixelHeight);

      //   // Set the options object
      //   var options:any = {};

      //   options = this.option;
        
      //   if (maskCanvas) {
      //     options.clearCanvas = false;

      //     /* Determine bgPixel by creating
      //        another canvas and fill the specified background color. */
      //     var bctx:any = document.createElement('canvas').getContext('2d');

      //     bctx.fillStyle = options.backgroundColor || '#fff';
      //     bctx.fillRect(0, 0, 1, 1);
      //     var bgPixel = bctx.getImageData(0, 0, 1, 1).data;

      //     var maskCanvasScaled:any =
      //       document.createElement('canvas');
      //     maskCanvasScaled.width = $canvas[0].width;
      //     maskCanvasScaled.height = $canvas[0].height;
      //     var ctx:any = maskCanvasScaled.getContext('2d');

      //     ctx.drawImage(maskCanvas,
      //       0, 0, maskCanvas.width, maskCanvas.height,
      //       0, 0, maskCanvasScaled.width, maskCanvasScaled.height);

      //     var imageData = ctx.getImageData(0, 0, $canvas.width, $canvas.height);
      //     var newImageData = ctx.createImageData(imageData);
      //     for (var i = 0; i < imageData.data.length; i += 4) {
      //       if (imageData.data[i + 3] > 128) {
      //         newImageData.data[i] = bgPixel[0];
      //         newImageData.data[i + 1] = bgPixel[1];
      //         newImageData.data[i + 2] = bgPixel[2];
      //         newImageData.data[i + 3] = bgPixel[3];
      //       } else {
      //         // This color must not be the same w/ the bgPixel.
      //         newImageData.data[i] = bgPixel[0];
      //         newImageData.data[i + 1] = bgPixel[1];
      //         newImageData.data[i + 2] = bgPixel[2];
      //         newImageData.data[i + 3] = bgPixel[3] ? (bgPixel[3] - 1) : 0;
      //       }
      //     }

      //     ctx.putImageData(newImageData, 0, 0);

      //     ctx = $canvas[0].getContext('2d');
      //     ctx.drawImage(maskCanvasScaled, 0, 0);

      //     maskCanvasScaled = ctx = imageData = newImageData = bctx = bgPixel = undefined;
      //   }

      //   console.log(options)
      //   WordCloud($canvas[0], options);
      }


  maskChange() {



   var options:any = {};

        options = this.option;

    // this.maskCanvas = document.getElementById('canvasM') as HTMLImageElement;
       var maskCanvas = null;
        // var file = $mask[0].files[0];
        var file = (<HTMLInputElement>document.getElementById('config-mask')).files![0];


        if (!file) {
          return;
        }

        var url = window.URL.createObjectURL(file);
        var img = new Image();
        img.src = url;

        // img.onload = function readPixels() {
        img.addEventListener('load', function() {
          window.URL.revokeObjectURL(url);

          maskCanvas = document.createElement('canvas');


          // this.maskCanvas = ;
          maskCanvas.width = img.width;
          maskCanvas.height = img.height;
console.log(maskCanvas);
          var ctx:any = maskCanvas.getContext('2d');
console.log(ctx);
          ctx.drawImage(img, 0, 0, img.width, img.height);

          var imageData:any = ctx.getImageData(
            0, 0, maskCanvas.width, maskCanvas.height);
          var newImageData:any = ctx.createImageData(imageData);

          for (var i = 0; i < imageData.data.length; i += 4) {
            var tone = imageData.data[i] +
              imageData.data[i + 1] +
              imageData.data[i + 2];
            var alpha = imageData.data[i + 3];

            if (alpha < 128 || tone > 128 * 3) {
              // Area not to draw
              newImageData.data[i] =
                newImageData.data[i + 1] =
                newImageData.data[i + 2] = 255;
              newImageData.data[i + 3] = 0;
            } else {
              // Area to draw
              newImageData.data[i] =
                newImageData.data[i + 1] =
                newImageData.data[i + 2] = 0;
              newImageData.data[i + 3] = 255;
            }
          }

          // maskCanvas =  maskCanvas;
         // maskCanvas;

          ctx.putImageData(newImageData, 0, 0);











var $form = $('#form');
      var $canvas = $('#canvas');
      var $loading = $('#loading');

      var $width = $('#config-width');
      var $height = $('#config-height');
      var $mask = <HTMLInputElement>document.getElementById('config-mask');
      var $dppx = $('#config-dppx');
      var $css = $('#config-css');
      var $webfontLink = $('#link-webfont');

        $loading.prop('hidden', false);

        // Load web font
        $webfontLink.prop('href', $css.val());

        // devicePixelRatio
        var devicePixelRatio = parseFloat($dppx.val());

        // Set the width and height
        var width = $width.val() ? $width.val() : $('#canvas-container').width();
        var height = $height.val() ? $height.val() : Math.floor(width * 0.65);
        var pixelWidth = width;
        var pixelHeight = height;

        if (devicePixelRatio !== 1) {
          $canvas.css({'width': width + 'px', 'height': height + 'px'});

          pixelWidth *= devicePixelRatio;
          pixelHeight *= devicePixelRatio;
        } else {
          $canvas.css({'width': '', 'height': '' });
        }

        $canvas.attr('width', pixelWidth);
        $canvas.attr('height', pixelHeight);

        // Set the options object
        // var options:any = {};

        // options = this.option;
        
        if (maskCanvas) {
          options.clearCanvas = false;

          /* Determine bgPixel by creating
             another canvas and fill the specified background color. */
          var bctx:any = document.createElement('canvas').getContext('2d');

          bctx.fillStyle = options.backgroundColor || '#fff';
          bctx.fillRect(0, 0, 1, 1);
          var bgPixel = bctx.getImageData(0, 0, 1, 1).data;

          var maskCanvasScaled:any =
            document.createElement('canvas');
          maskCanvasScaled.width = $canvas[0].width;
          maskCanvasScaled.height = $canvas[0].height;
          var ctx2:any = maskCanvasScaled.getContext('2d');

          ctx2.drawImage(maskCanvas,
            0, 0, maskCanvas.width, maskCanvas.height,
            0, 0, maskCanvasScaled.width, maskCanvasScaled.height);

          var imageData:any = ctx2.getImageData(0, 0, 900,600);
console.log(maskCanvas);

          var newImageData:any = ctx2.createImageData(imageData);
          for (var i = 0; i < imageData.data.length; i += 4) {
            if (imageData.data[i + 3] > 128) {
              newImageData.data[i] = bgPixel[0];
              newImageData.data[i + 1] = bgPixel[1];
              newImageData.data[i + 2] = bgPixel[2];
              newImageData.data[i + 3] = bgPixel[3];
            } else {
              // This color must not be the same w/ the bgPixel.
              newImageData.data[i] = bgPixel[0];
              newImageData.data[i + 1] = bgPixel[1];
              newImageData.data[i + 2] = bgPixel[2];
              newImageData.data[i + 3] = bgPixel[3] ? (bgPixel[3] - 1) : 0;
            }
          }

          ctx2.putImageData(newImageData, 0, 0);

          ctx2 = $canvas[0].getContext('2d');
          ctx2.drawImage(maskCanvasScaled, 0, 0);

          maskCanvasScaled = ctx2 = imageData = newImageData = bctx = bgPixel = undefined;
        }

        console.log(options)
        setTimeout(()=> {
            WordCloud($canvas[0], options);
        });
















        });
  }






}
